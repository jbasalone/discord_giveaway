import { Client, GatewayIntentBits, Partials, Events } from 'discord.js';
import dotenv from 'dotenv';
import { connectDB } from './database';
import { handleGiveawayEnd } from './events/giveawayEnd';

import { execute as executeStartTemplate } from './commands/startTemplate';
import { execute as executeSaveTemplate } from './commands/saveTemplate';
import { execute as executeListTemplates } from './commands/listTemplates';
import { execute as executeDeleteTemplate } from './commands/deleteTemplate';
import { execute as executeShowConfig } from './commands/showConfig';
import { execute as executeHelp } from './commands/help';
import { execute as executeReroll } from './commands/reroll';
import { setGuildPrefix } from './commands/setprefix';
import { getGuildPrefix } from './utils/getGuildPrefix';
import { execute as executeGiveaway } from './commands/giveaway';
import { execute as executeCustomGiveaway } from './commands/customGiveaway';
import { executeJoinLeave } from './events/giveawayJoin';

dotenv.config();

// ✅ Initialize Discord Bot
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

// ✅ Async Wrapper Function to Start the Bot
async function startBot() {
  try {
    console.log("🔗 Connecting to Database...");
    await connectDB(); // ✅ Now inside an async function

    client.once(Events.ClientReady, async () => {
      console.log(`✅ Bot is online! Logged in as ${client.user?.tag}`);

      // ✅ Run Giveaway End Check every 1 second
      setInterval(() => {
        console.log("⏳ Checking for expired giveaways...");
        handleGiveawayEnd(client);
      }, 1000);
    });

    // ✅ Message-based Command Handling
    client.on(Events.MessageCreate, async (message) => {
      if (message.author.bot || !message.guild) return;

      const guildId = message.guild.id;
      const prefix = await getGuildPrefix(guildId); // ✅ Get per-guild prefix

      if (!message.content.startsWith(prefix)) return; // ✅ Ensure correct prefix

      const args = message.content.slice(prefix.length).trim().split(/\s+/);
      const subCommand = args.shift()?.toLowerCase();

      if (subCommand !== 'ga') return; // ✅ Ensure `ga` is used before processing

      const command = args.shift()?.toLowerCase();

      console.log(`🔍 Command Detected: "${command}" with Args: [${args.join(', ')}]`);

      try {
        if (command === 'create') {
          await executeGiveaway(message, args);
        } else if (command === 'custom') {
          await executeCustomGiveaway(message, args);
        } else if (command === 'starttemplate') {
          await executeStartTemplate(message, args, client);
        } else if (command === 'setprefix' && args.length === 1) {
          await setGuildPrefix(message, args[0]); // ✅ Allow server admins to change prefix
        } else if (command === 'save') {
          await executeSaveTemplate(message, args);
        } else if (command === 'listtemplates') {
          await executeListTemplates(message);
        } else if (command === 'deletetemplate') {
          await executeDeleteTemplate(message, args);
        } else if (command === 'showconfig') {
          await executeShowConfig(message);
        } else if (command === 'reroll') {
          await executeReroll(message, args);
        } else if (command === 'help') {
          await executeHelp(message);
        } else {
          await message.reply(`❌ Unknown command. Use \`${prefix} ga help\` to see available commands.`);
        }
      } catch (error) {
        console.error(`❌ Error executing command '${command}':`, error);
        await message.reply("❌ An error occurred while processing your command.");
      }
    });

    // ✅ Button Interaction Handling (Join/Leave Giveaway)
    client.on(Events.InteractionCreate, async (interaction) => {
      if (!interaction.isButton()) return;

      try {
        await executeJoinLeave(interaction);
      } catch (error) {
        console.error('❌ Error handling button interaction:', error);
        await interaction.reply({ content: '❌ An error occurred.', ephemeral: true });
      }
    });

    // ✅ Login to Discord
    await client.login(process.env.DISCORD_TOKEN);
  } catch (error) {
    console.error("❌ Fatal error during startup:", error);
  }
}

// ✅ Start the bot using the async function
export { client };
startBot();