import { DataTypes, Model } from 'sequelize';
import { sequelize } from '../database';

export class Giveaway extends Model {
    declare id: number;
    declare host: string;
    declare channelId: string;
    declare messageId: string;
    declare title: string;
    declare description: string;
    declare role: string | null;
    declare duration: number;
    declare endsAt: number;
    declare participants: string[];
    declare winnerCount: number;
    declare extraFields: object;
}

Giveaway.init(
    {
        id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
        host: { type: DataTypes.STRING, allowNull: false },
        channelId: { type: DataTypes.STRING, allowNull: false },
        messageId: { type: DataTypes.STRING, allowNull: false, unique: true },
        title: { type: DataTypes.STRING, allowNull: false },
        description: { type: DataTypes.STRING, allowNull: false, defaultValue: "React to enter!" },
        role: { type: DataTypes.STRING, allowNull: true },
        duration: { type: DataTypes.INTEGER, allowNull: false },
        endsAt: { type: DataTypes.INTEGER, allowNull: false },
        participants: {
            type: DataTypes.TEXT,
            allowNull: false,
            defaultValue: "[]",
            get() {
                return JSON.parse(this.getDataValue("participants"));
            },
            set(value: string[] | string) {
                this.setDataValue("participants", JSON.stringify(value));
            }
        },
        winnerCount: { type: DataTypes.INTEGER, allowNull: false },
        extraFields: {
            type: DataTypes.JSON,
            allowNull: false,
            defaultValue: {}
        }
    },
    {
        sequelize,
        modelName: "Giveaway",
        tableName: "Giveaways", // ✅ Force table name
        timestamps: true
    }
);