import { DataTypes, Model } from 'sequelize';
import { sequelize } from '../database';

class GuildSettings extends Model {
    public guildId!: string;
    public defaultGiveawayRoleId!: string;
    public prefix!: string; // ✅ Ensure prefix column exists
}

GuildSettings.init({
    guildId: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true
    },
    defaultGiveawayRoleId: {
        type: DataTypes.STRING,
        allowNull: true
    },
    prefix: {  // ✅ New Column: Stores server-specific prefix
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: "!"  // ✅ Default prefix is "!"
    }
}, { sequelize, modelName: 'GuildSettings' });

export { GuildSettings };