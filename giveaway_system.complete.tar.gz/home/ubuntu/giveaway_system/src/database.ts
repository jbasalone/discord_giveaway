import { Sequelize } from 'sequelize';
import dotenv from 'dotenv';

dotenv.config();

export const sequelize = new Sequelize(
    process.env.MYSQL_DATABASE!,
    process.env.MYSQL_USER!,
    process.env.MYSQL_PASSWORD!,
    {
        host: process.env.MYSQL_HOST,
        dialect: "mysql",
        logging: false
    }
);

export async function closeDB() {
    try {
        await sequelize.close();
        console.log("✅ Database connection closed.");
    } catch (error) {
        console.error("❌ Error closing database connection:", error);
    }
}

export async function connectDB() {
    try {
        await sequelize.authenticate();
        console.log("✅ Database connected successfully.");

        // Ensure tables are created before bot starts
        await sequelize.sync({ alter: true });
        console.log("✅ All tables synchronized.");
    } catch (error) {
        console.error("❌ Database connection error:", error);
        process.exit(1);
    }
}

