import { startLiveCountdown } from './utils/giveawayTimer';
import { Giveaway } from './models/Giveaway';
import { Client, Message, TextChannel } from 'discord.js';
import { sequelize } from './database';

// ✅ Mock Discord Client
const mockClient = new Client({ intents: [] });

async function runTest() {
    console.log("🚀 Starting Giveaway Test...");

    await sequelize.sync();

    const templateName = "Dragon Raid";
    console.log(`✅ Saving template: ${templateName}`);
    await Giveaway.create({
        host: "test_host",
        channelId: "test_channel",
        messageId: "test_message",
        title: "Test Giveaway",
        description: "React to enter!",
        duration: 600000,
        endsAt: Math.floor(Date.now() / 1000) + 600,
        participants: JSON.stringify(["user1", "user2"]),
        winnerCount: 2,
        extraFields: JSON.stringify([
            { name: "📌 Info", value: "Level 50+ required" },
            { name: "⚔ Requirement", value: "Must have Tier 3 Gear" }
        ])
    });

    console.log("🎉 Giveaway Created");

    const mockMessage = {
        id: "test_message",
        channel: {} as TextChannel,
        embeds: [],
        edit: jest.fn(async (data) => {
            console.log("Embed Updated:", data);
            return { ...mockMessage, embeds: data.embeds };
        })
    } as unknown as Message;

    // ✅ Fix: Pass `mockClient`
    await startLiveCountdown(mockMessage, 1, mockClient);

    console.log("🏆 Ending Giveaway...");
}

export { runTest };