import { Message, Client, EmbedBuilder } from 'discord.js';
import { Giveaway } from '../models/Giveaway';

/**
 * Updates the giveaway countdown in an embed message.
 * @param message The Discord message containing the giveaway embed.
 * @param giveawayId The ID of the giveaway in the database.
 * @param client The Discord client instance.
 */
export async function startLiveCountdown(
    message: Message,
    giveawayId: number,
    client: Client
) {
    try {
        const giveaway = await Giveaway.findByPk(giveawayId);
        if (!giveaway) {
            console.warn(`⚠️ Giveaway ${giveawayId} not found.`);
            return;
        }

        console.log(`🔄 Updating countdown for Giveaway ${giveawayId}`);

        let existingEmbed = message.embeds[0]
            ? EmbedBuilder.from(message.embeds[0])
            : new EmbedBuilder().setTitle("🎉 Giveaway Ongoing!");

        existingEmbed.setFields([
            { name: "🎟️ Total Participants", value: `${giveaway.participants.length} users`, inline: true },
            { name: "⏳ Ends In", value: `<t:${giveaway.endsAt}:R>`, inline: true },
        ]);

        await message.edit({ embeds: [existingEmbed] });
        console.log("DEBUG: Giveaway endsAt:", giveaway.endsAt);

        console.log(`✅ Countdown updated successfully for Giveaway ${giveawayId}`);

        setTimeout(() => startLiveCountdown(message, giveawayId, client), 10000).unref();
    } catch (error) {
        console.error("❌ Error updating giveaway countdown:", error);
    }
}