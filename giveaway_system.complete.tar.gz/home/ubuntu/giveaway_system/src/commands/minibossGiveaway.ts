import { Message, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, TextChannel, GuildMember } from 'discord.js';
import { Giveaway } from '../models/Giveaway';
import { convertToMilliseconds } from '../utils/convertTime';
import { startLiveCountdown } from '../utils/giveawayTimer';
import config from '../config.json';
import { client } from '../index';

export async function execute(message: Message, args: string[]) {
    try {
        if (args.length < 2) return message.reply("❌ Invalid usage! Example: `!ga mb \"Mega Boss\" 10m --field \"Requirement: Level 50+\"`");

        const guildId = message.guild?.id;
        if (!guildId || !config.allowedGuilds[guildId as keyof typeof config.allowedGuilds]) {
            return message.reply("❌ This command is not allowed in this server.");
        }

        // ✅ Check if the user has the Miniboss Host role
        const allowedRoles: string[] = config.allowedGuilds[guildId as keyof typeof config.allowedGuilds] || [];
        const member = message.member as GuildMember;
        if (!member.roles.cache.some(role => allowedRoles.includes(role.id))) {
            return message.reply("❌ You must have the **Miniboss Host** role to start a Miniboss giveaway!");
        }

        // ✅ Extract title
        const titleMatch = message.content.match(/"(.+?)"/);
        const title = titleMatch ? titleMatch[1] : '🐲 Miniboss Giveaway 🐲';

        const durationArg = args.find(arg => arg.match(/\d+[smhd]/)) || '1m';
        const duration = convertToMilliseconds(durationArg);
        if (duration <= 0) return message.reply("❌ Invalid duration!");

        const endsAt = Math.floor(Date.now() / 1000) + Math.floor(duration / 1000);
        const channel = message.channel as TextChannel;

        // ✅ Extract & prevent duplicate `--field` values
        const extraFields: { name: string; value: string }[] = [];
        const fieldRegex = /--field\s"(.+?)"/g;
        let match: RegExpExecArray | null;
        while ((match = fieldRegex.exec(message.content)) !== null) {
            const fieldValue = match?.[1];
            if (fieldValue && !extraFields.some(field => field.value === fieldValue)) {
                extraFields.push({ name: '📌 Info', value: fieldValue });
            }
        }

        // ✅ Miniboss giveaways **always have 10 winners** (including host)
        const winnerCount = 9;

        // ✅ Store giveaway data in the database **(Fixed missing await)**
        const giveawayData = await Giveaway.create({
            host: message.author.id,
            channelId: channel.id,
            messageId: null,
            title,
            description: 'React with 🐲 to enter the Miniboss!',
            role: null,
            duration,
            endsAt,
            participants: JSON.stringify([message.author.id]), // ✅ The host is auto-included
            winnerCount,
            extraFields: JSON.stringify(extraFields.length > 0 ? extraFields : [])
        });

        // ✅ Construct the embed
        const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription("React with 🐲 to enter the Miniboss!")
            .setColor("DarkRed");

        // ✅ Preserve extra fields
        extraFields.forEach(field => embed.addFields(field));

        embed.addFields(
            { name: "⏳ Ends In", value: `${Math.floor(duration / 1000)}s`, inline: true },
            { name: "🏆 Winners", value: `10 (Including Host)`, inline: true },
            { name: "🎟️ Total Participants", value: `1 user (Host)`, inline: true }
        );

        // ✅ Add join/leave buttons
        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`join-${giveawayData.getDataValue('id')}`).setLabel('Join 🐲').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`leave-${giveawayData.getDataValue('id')}`).setLabel('Leave ❌').setStyle(ButtonStyle.Danger)
        );

        // ✅ Send the embed **(Fixed missing await)**
        const giveawayMessage = await channel.send({
            embeds: [embed],
            components: [row],
        });

        // ✅ Store message ID **(Fixed missing await)**
        giveawayData.messageId = giveawayMessage.id;
        await giveawayData.save();

        // ✅ Start countdown timer **(Fixed missing await)**
        await startLiveCountdown(giveawayMessage, giveawayData.getDataValue('id'), client);
    } catch (error) {
        console.error("❌ Error starting Miniboss giveaway:", error);
    }
}