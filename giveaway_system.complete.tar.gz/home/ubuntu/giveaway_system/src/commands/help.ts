import { Message, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } from 'discord.js';

export async function execute(message: Message) {
    try {
        const embed = new EmbedBuilder()
            .setTitle("🎉 Giveaway Bot Help Menu 🎉")
            .setDescription("Here are the available giveaway commands. Use them wisely!")
            .setColor("Blue");

        const commands = {
            "Basic Commands": [
                { name: "`!ga create <duration> <winners>`", value: "Starts a new giveaway. Example: `!ga create 30s 1`" },
                { name: "`!ga custom <title> <duration> <winners> [--field \"info\"]`", value: "Starts a custom giveaway with additional fields." },
                { name: "`!ga reroll <giveawayID>`", value: "🔄 **Rerolls winners** for a completed giveaway." },
            ],
            "Template Commands": [
                { name: "`!ga save <name>`", value: "Saves the current giveaway setup as a template." },
                { name: "`!ga starttemplate <name>`", value: "Starts a giveaway from a saved template." },
                { name: "`!ga listtemplates`", value: "Lists all saved giveaway templates." },
                { name: "`!ga deletetemplate <name>`", value: "Deletes a saved giveaway template." },
            ],
            "Admin Commands": [
                { name: "`!ga setprefix <prefix>`", value: "Sets a custom prefix for the server." },
                { name: "`!ga showconfig`", value: "Displays the current giveaway settings for the server." },
            ]
        };

        for (const [category, cmds] of Object.entries(commands)) {
            embed.addFields({ name: `**${category}**`, value: cmds.map(cmd => `${cmd.name}\n➡ ${cmd.value}`).join("\n\n") });
        }

        const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId("help-menu")
                .setPlaceholder("📜 Select a command category...")
                .addOptions(
                    new StringSelectMenuOptionBuilder().setLabel("🎉 Basic Commands").setValue("basic"),
                    new StringSelectMenuOptionBuilder().setLabel("📜 Template Commands").setValue("template"),
                    new StringSelectMenuOptionBuilder().setLabel("⚙️ Admin Commands").setValue("admin")
                )
        );

        await message.reply({ embeds: [embed], components: [row] });
    } catch (error) {
        console.error("❌ Error displaying help:", error);
        return message.reply("❌ An error occurred while displaying help.");
    }
}