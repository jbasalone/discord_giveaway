import { Message } from 'discord.js';
import { ExtraEntries } from '../models/ExtraEntries';

export async function executeSetExtraEntries(message: Message, args: string[]) {
  if (!message.member?.permissions.has("Administrator")) {
    return message.reply("❌ You need Administrator permissions to use this command.");
  }

  const role = message.mentions.roles.first();
  const bonusEntries = parseInt(args[1]) || 1;

  if (!role) {
    return message.reply("❌ Please mention a role and specify the number of extra entries.");
  }

  await ExtraEntries.upsert({
    guildId: message.guild!.id,
    roleId: role.id,
    bonusEntries
  });

  message.reply(`✅ Users with the ${role.name} role will now receive **${bonusEntries} extra entries** in giveaways.`);
}
