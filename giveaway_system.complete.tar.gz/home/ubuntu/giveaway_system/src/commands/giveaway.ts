import { Message, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, TextChannel } from 'discord.js';
import { Giveaway } from '../models/Giveaway';
import { convertToMilliseconds } from '../utils/convertTime';
import { startLiveCountdown } from '../utils/giveawayTimer';
import { client } from '../index';

export async function execute(message: Message, args: string[]) {
    try {
        if (args.length < 2) return message.reply("❌ Invalid usage! Example: `!ga create 30s 1`");

        const durationArg = args[0];
        const winnerCountArg = args[1];

        const duration = convertToMilliseconds(durationArg);
        if (duration <= 0) return message.reply("❌ Invalid duration!");

        const winnerCount = parseInt(winnerCountArg, 10);
        if (isNaN(winnerCount) || winnerCount < 1) return message.reply("❌ Invalid winner count!");

        const endsAt = Math.floor(Date.now() / 1000) + Math.floor(duration / 1000);
        const channel = message.channel as TextChannel;

        const giveawayData = await Giveaway.create({
            host: message.author.id,
            channelId: channel.id,
            messageId: null,
            title: "🎉 Giveaway 🎉",
            description: "React with 🎉 to enter!",
            role: null,
            duration,
            endsAt,
            participants: JSON.stringify([]),
            winnerCount
        });

        const embed = new EmbedBuilder()
            .setTitle("🎉 Giveaway 🎉")
            .setDescription("React with 🎉 to enter!")
            .setColor("Gold");

        // ✅ Only add "Total Participants" once
        embed.setFields([
            { name: "⏳ Ends In", value: `${Math.floor(duration / 1000)}s`, inline: true },
            { name: "🏆 Winners", value: `${winnerCount}`, inline: true },
            { name: "🎟️ Total Participants", value: `0 users`, inline: true }
        ]);

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`join-${giveawayData.getDataValue('id')}`).setLabel('Join 🎉').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`leave-${giveawayData.getDataValue('id')}`).setLabel('Leave ❌').setStyle(ButtonStyle.Danger)
        );

        const giveawayMessage = await channel.send({
            embeds: [embed],
            components: [row],
        });

        giveawayData.messageId = giveawayMessage.id;
        await giveawayData.save();

        startLiveCountdown(giveawayMessage, giveawayData.getDataValue('id'), client);    } catch (error) {
        console.error("❌ Error starting giveaway:", error);
    }
}