import { Message, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, TextChannel } from 'discord.js';
import { Giveaway } from '../models/Giveaway';
import { convertToMilliseconds } from '../utils/convertTime';
import { startLiveCountdown } from '../utils/giveawayTimer';
import { client } from '../index';

export async function execute(message: Message, args: string[]) {
    try {
        if (args.length < 3) return message.reply("❌ Invalid usage! Example: `!ga custom \"Mega Prize\" 10m 3 --field \"Requirement: Level 50+\"`");

        // ✅ Extract full title for multi-word titles
        const titleMatch = message.content.match(/"(.+?)"/);
        const title = titleMatch ? titleMatch[1] : '🎉 Custom Giveaway 🎉';

        const durationArg = args.find(arg => arg.match(/\d+[smhd]/)) || '1m';
        const winnerCountArg = args.find(arg => !isNaN(Number(arg))) || '1';

        const duration = convertToMilliseconds(durationArg);
        if (duration <= 0) return message.reply("❌ Invalid duration!");

        const winnerCount = parseInt(winnerCountArg, 10);
        if (isNaN(winnerCount) || winnerCount < 1) return message.reply("❌ Invalid winner count!");

        const endsAt = Math.floor(Date.now() / 1000) + Math.floor(duration / 1000);
        const channel = message.channel as TextChannel;

        // ✅ Extract & prevent duplicate `--field` values
        const extraFields: { name: string; value: string }[] = [];
        const fieldRegex = /--field\s"(.+?)"/g;
        let match: RegExpExecArray | null;

        while ((match = fieldRegex.exec(message.content)) !== null) {
            const fieldValue = match?.[1];
            if (fieldValue && !extraFields.some((field) => field.value === fieldValue)) { // ✅ Prevent duplicates
                extraFields.push({ name: '📌 Info', value: fieldValue });
            }
        }

        // ✅ Store giveaway with `extraFields`
        const giveawayData = await Giveaway.create({
            host: message.author.id,
            channelId: channel.id,
            messageId: null,
            title,
            description: 'React with 🎉 to enter!',
            role: null,
            duration,
            endsAt,
            participants: JSON.stringify([]),
            winnerCount,
            extraFields: JSON.stringify(extraFields.length > 0 ? extraFields : []) // ✅ Store fields
        });

        const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription("React with 🎉 to enter!")
            .setColor("Gold");

        // ✅ Preserve `--field` values & avoid duplicates
        const uniqueFields = extraFields.filter((field, index, self) =>
            self.findIndex(f => f.name === field.name) === index // ✅ Keep only unique
        );

        embed.setFields([
            ...uniqueFields, // ✅ Keep extra fields
            { name: "⏳ Ends In", value: `${Math.floor(duration / 1000)}s`, inline: true },
            { name: "🏆 Winners", value: `${winnerCount}`, inline: true }, // ✅ Fix duplicate Winner Count
            { name: "🎟️ Total Participants", value: `0 users`, inline: true }
        ]);

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`join-${giveawayData.getDataValue('id')}`).setLabel('Join 🎉').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`leave-${giveawayData.getDataValue('id')}`).setLabel('Leave ❌').setStyle(ButtonStyle.Danger)
        );

        const giveawayMessage = await channel.send({
            embeds: [embed],
            components: [row],
        });

        giveawayData.messageId = giveawayMessage.id;
        await giveawayData.save();

        startLiveCountdown(giveawayMessage, giveawayData.getDataValue('id'), client);    } catch (error) {
        console.error("❌ Error starting custom giveaway:", error);
    }
}
