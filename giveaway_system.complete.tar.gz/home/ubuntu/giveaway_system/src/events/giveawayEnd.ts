import { Client, TextChannel, EmbedBuilder } from 'discord.js';
import { Giveaway } from '../models/Giveaway';
import { Op } from 'sequelize';

export async function handleGiveawayEnd(client: Client) {
  try {
    console.log("🔍 Checking for ended giveaways...");
    const currentTime = Math.floor(Date.now() / 1000);
    console.log(`⏳ Current Time (Unix Seconds): ${currentTime}`);

    const expiredGiveaways = await Giveaway.findAll({
      where: { endsAt: { [Op.lte]: currentTime } }
    });

    console.log(`🔎 Found ${expiredGiveaways.length} expired giveaways.`);

    if (expiredGiveaways.length === 0) {
      console.log("✅ No giveaways to end.");
      return;
    }

    for (const giveaway of expiredGiveaways) {
      console.log(`🏁 Ending Giveaway ID: ${giveaway.id}`);

      const channel = client.channels.cache.get(giveaway.channelId) as TextChannel;
      if (!channel) {
        console.error(`❌ Giveaway ${giveaway.id} - Channel not found!`);
        continue;
      }

      let giveawayMessage;
      if (giveaway.messageId) {
        try {
          giveawayMessage = await channel.messages.fetch(giveaway.messageId);
          console.log(`📩 Successfully fetched Giveaway Message ID: ${giveaway.messageId}`);
        } catch (error) {
          console.warn(`⚠️ Giveaway ${giveaway.id} message not found, skipping update.`);
          continue;
        }
      }

      const participants: string[] = typeof giveaway.participants === "string"
          ? JSON.parse(giveaway.participants)
          : giveaway.participants;
      const winnerCount = giveaway.winnerCount || 1;
      if (participants.length === 0) {
        console.log(`❌ No participants for Giveaway ID: ${giveaway.id}`);
        continue;
      }

      // ✅ Shuffle and select **unique** winners **only once**
      const shuffledParticipants = participants.sort(() => Math.random() - 0.5);
      const uniqueWinnerIds = Array.from(new Set(shuffledParticipants.slice(0, winnerCount)));

      // ✅ DELETE GIVEAWAY **BEFORE** ANNOUNCEMENT TO PREVENT MULTIPLE MESSAGES
      try {
        await giveaway.destroy();
        console.log(`✅ Giveaway ID ${giveaway.id} has been removed from the database.`);
      } catch (error) {
        console.error(`❌ Failed to delete giveaway ID ${giveaway.id} from database - ${error}`);
        continue; // ✅ Skip further processing if delete fails
      }

      // ✅ Format winners for announcement
      const winnersMention = uniqueWinnerIds.length > 0
          ? uniqueWinnerIds.map(id => `<@${id}>`).join(', ')
          : "No winners 😢";

      console.log(`🏆 Giveaway ${giveaway.id} Winners: ${winnersMention}`);

      if (giveawayMessage) {
        try {
          const existingEmbed = giveawayMessage.embeds[0];

          if (existingEmbed) {
            // ✅ Remove duplicate fields & fix countdown timer
            const filteredFields = existingEmbed.fields.filter(
                field => !["🏆 Winners", "⏳ Ends In", "🎟️ Total Participants", "👥 Total Participants"].includes(field.name)
            );

            const updatedEmbed = EmbedBuilder.from(existingEmbed)
                .setTitle("🎉 Giveaway Ended! 🎉")
                .setColor("Red")
                .setFields([
                  ...filteredFields,
                  { name: "🎟️ Total Participants", value: `${participants.length} users`, inline: true },
                  { name: "🎯 Winner Count", value: `${winnerCount}`, inline: true },
                  { name: "🏆 Winners", value: winnersMention, inline: false },
                  { name: "⏳ Status", value: "Ended!", inline: true } // ✅ Fixes countdown not being removed
                ]);

            await giveawayMessage.edit({ embeds: [updatedEmbed], components: [] });
            console.log(`✅ Giveaway ${giveaway.id} embed successfully updated.`);
          }
        } catch (error) {
          console.error(`❌ Failed to update giveaway embed for ID: ${giveaway.id} - ${error}`);
        }
      }

      // ✅ ENSURE ONLY **ONE** WINNER ANNOUNCEMENT IS SENT
      try {
        await channel.send(
            `🎉 **Giveaway Ended!** **${giveaway.title}**\n🏆 **Winners:** ${winnersMention}\n🔗 [View Giveaway](https://discord.com/channels/${channel.guild.id}/${giveaway.channelId}/${giveaway.messageId})`
        );
        console.log(`✅ Winners announced in channel for Giveaway ID: ${giveaway.id}`);
      } catch (error) {
        console.error(`❌ Failed to announce winners in channel for Giveaway ID: ${giveaway.id} - ${error}`);
      }
    }
  } catch (error) {
    console.error("❌ Critical Error in `handleGiveawayEnd()`:", error);
  }
}