import { EmbedBuilder, TextChannel, ButtonInteraction } from 'discord.js';
import { Giveaway } from '../models/Giveaway';

export async function executeJoinLeave(interaction: ButtonInteraction) {
  try {
    if (!interaction.customId.startsWith("join-") && !interaction.customId.startsWith("leave-")) return;

    const isJoining = interaction.customId.startsWith("join-");
    const giveawayId = parseInt(interaction.customId.split("-")[1], 10);
    const userId = interaction.user.id;

    console.log(`🔍 Processing giveaway ID: ${giveawayId}, User ID: ${userId}, Joining: ${isJoining}`);

    let giveaway = await Giveaway.findByPk(giveawayId);

    if (!giveaway) {
      console.warn(`⚠️ Giveaway with ID ${giveawayId} not found. Retrying...`);

      // 🔁 **Wait 500ms and force sync the database before retrying**
      await new Promise((resolve) => setTimeout(resolve, 500));
      await Giveaway.sync();

      giveaway = await Giveaway.findByPk(giveawayId);

      if (!giveaway) {
        console.error(`❌ Giveaway with ID ${giveawayId} still not found after retry.`);
        return interaction.reply({ content: "❌ Giveaway not found.", ephemeral: true });
      }
    }

    console.log(`✅ Giveaway ${giveawayId} found, processing user action.`);

    const participants: string[] = giveaway.participants;
    const alreadyJoined = participants.includes(userId);

    if (isJoining) {
      if (alreadyJoined) {
        console.log(`⚠️ User ${userId} already joined.`);
        return interaction.reply({ content: "⚠️ You have already joined this giveaway!", ephemeral: true });
      }
      if (participants.length >= 9) {
        console.log(`⚠️ Giveaway ${giveawayId} is full.`);
        return interaction.reply({ content: "⚠️ This Miniboss Giveaway is already full (9 players max).", ephemeral: true });
      }
      participants.push(userId);
      console.log(`✅ User ${userId} joined giveaway ${giveawayId}.`);
    } else {
      if (!alreadyJoined) {
        console.log(`⚠️ User ${userId} tried to leave but wasn't in the giveaway.`);
        return interaction.reply({ content: "⚠️ You are not in this giveaway!", ephemeral: true });
      }
      const index = participants.indexOf(userId);
      if (index !== -1) {
        participants.splice(index, 1);
        console.log(`✅ User ${userId} left giveaway ${giveawayId}.`);
      }
    }

    giveaway.participants = participants;
    await giveaway.save();

    await interaction.reply({
      content: isJoining ? "✅ You have successfully joined the Miniboss giveaway!" : "✅ You have left the giveaway.",
      ephemeral: true
    });

    const channel = interaction.channel as TextChannel;
    let giveawayMessage;

    if (giveaway.messageId) {
      try {
        giveawayMessage = await channel.messages.fetch(giveaway.messageId);
        console.log(`📩 Giveaway message fetched successfully: ${giveaway.messageId}`);
      } catch (error) {
        console.warn(`⚠️ Giveaway message with ID ${giveaway.messageId} not found, skipping update.`);
      }
    }

    if (!giveawayMessage || giveawayMessage.embeds.length === 0) {
      console.warn(`⚠️ Giveaway message is missing or has no embed. Skipping update.`);
      return;
    }

    const embed = new EmbedBuilder(giveawayMessage.embeds[0].toJSON());

    // ✅ Remove previous "Total Participants" field before adding a new one
    const filteredFields = embed.data.fields?.filter(field => field.name !== "🎟️ Total Participants") || [];

    embed.setFields([
      ...filteredFields,
      { name: "🎟️ Total Participants", value: `${participants.length} users`, inline: true }
    ]);

    console.log(`🔄 Updating giveaway embed for message ID ${giveaway.messageId}...`);
    await giveawayMessage.edit({ embeds: [embed] });
    console.log(`✅ Giveaway embed updated successfully.`);
  } catch (error) {
    console.error("❌ Error handling giveaway join/leave:", error);
  }
}